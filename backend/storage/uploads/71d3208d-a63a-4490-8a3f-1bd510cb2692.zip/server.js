require('dotenv').config();
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const jwt        = require('jsonwebtoken');
const mongoose   = require('mongoose');
const path       = require('path');
const fs         = require('fs');

const authRoutes    = require('./routes/auth');
const userRoutes    = require('./routes/users');
const chatRoutes    = require('./routes/chats');
const messageRoutes = require('./routes/messages');
const deleteRoutes  = require('./routes/messageDelete');

// ── Папка для загружаемых файлов ──────────────────────────────────────────────
const UPLOAD_DIR = path.join(__dirname, '../storage/uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ── Express + HTTP + Socket.IO ────────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
    cors: { origin: '*', methods: ['GET','POST','PUT','DELETE'] },
});

app.set('io', io);
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use('/uploads', express.static(UPLOAD_DIR));

// ── REST маршруты ─────────────────────────────────────────────────────────────
app.use('/api',          authRoutes);
app.use('/api/users',    userRoutes);
app.use('/api/chats',    chatRoutes);
app.use('/api/chats',    messageRoutes);
app.use('/api/messages', deleteRoutes);

app.get('/api/health', (_, res) => res.json({ status: 'ok', time: new Date() }));
app.get('/api/online', (_, res) => res.json([...onlineUsers.keys()]));

// ── Socket.IO ─────────────────────────────────────────────────────────────────
const onlineUsers = new Map();

io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('Требуется авторизация'));
    try {
        socket.user = jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch {
        next(new Error('Недействительный токен'));
    }
});

io.on('connection', (socket) => {
    const userId = String(socket.user.id);
    socket.join(`user:${userId}`);
    onlineUsers.set(userId, socket.id);
    io.emit('user:online', userId);

    socket.on('typing:start', async ({ chatId }) => {
        try {
            const chat = await require('./models/Chat').findById(chatId).select('members');
            chat?.members.forEach(uid => {
                const id = String(uid);
                if (id !== userId) io.to(`user:${id}`).emit('typing:start', { userId, chatId, name: socket.user.display_name });
            });
        } catch (e) {}
    });

    socket.on('typing:stop', async ({ chatId }) => {
        try {
            const chat = await require('./models/Chat').findById(chatId).select('members');
            chat?.members.forEach(uid => {
                const id = String(uid);
                if (id !== userId) io.to(`user:${id}`).emit('typing:stop', { userId, chatId });
            });
        } catch (e) {}
    });

    socket.on('disconnect', () => {
        onlineUsers.delete(userId);
        io.emit('user:offline', userId);
    });
});

// ── Раздача фронтенда (для Railway) ──────────────────────────────────────────
// ВАЖНО: этот блок должен быть ПОСЛЕ всех /api маршрутов
const distPath = path.join(__dirname, '../../frontend/dist');
if (fs.existsSync(distPath)) {
    console.log('✅ Frontend dist найден, раздаём статику');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
    });
} else {
    console.log('⚠️  Frontend dist не найден — только API режим');
    app.get('*', (req, res) => {
        if (!req.path.startsWith('/api')) {
            res.status(200).json({ message: 'NexusChat API работает. Frontend не собран.' });
        }
    });
}

// ── Подключение к MongoDB и запуск ────────────────────────────────────────────
const PORT = process.env.PORT || 3001;

if (!process.env.MONGO_URL) {
    console.error('❌ MONGO_URL не задан! Создай файл backend/.env');
    console.error('   MONGO_URL=mongodb+srv://...');
    process.exit(1);
}

mongoose
    .connect(process.env.MONGO_URL)
    .then(() => {
        console.log('✅ Подключено к MongoDB');
        server.listen(PORT, '0.0.0.0', () => {
            console.log(`✅ Сервер запущен на порту ${PORT}`);
        });
    })
    .catch(err => {
        console.error('❌ Ошибка MongoDB:', err.message);
        process.exit(1);
    });
