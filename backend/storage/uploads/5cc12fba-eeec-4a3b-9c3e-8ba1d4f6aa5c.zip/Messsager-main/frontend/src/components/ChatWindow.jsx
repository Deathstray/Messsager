import { useState, useEffect, useRef, useCallback } from 'react';
import { IconAttach, IconSend, IconBack, IconReply, IconForward, IconCopy, IconStar, IconTrash, IconChat } from '../icons/Icons';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { apiFetch, fileUrl } from '../api';
import MessageBubble from './MessageBubble';
import { getChatDisplayName } from './ChatList';

function groupByDate(msgs) {
    const groups = []; let lastDate = null;
    msgs.forEach(msg => {
        const d = new Date(msg.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
        if (d !== lastDate) { groups.push({ date: d, msgs: [] }); lastDate = d; }
        groups[groups.length - 1].msgs.push(msg);
    });
    return groups;
}

const REACTIONS = ['👍','❤️','😂','😮','😢','🔥','👎'];

function MsgContextMenu({ x, y, msg, isMe, onClose, onReply, onForward, onSave, onReact, onDelete, onCopy }) {
    const { colors } = useTheme();
    const ref = useRef(null);
    useEffect(() => {
        const fn = e => { if (!ref.current?.contains(e.target)) onClose(); };
        document.addEventListener('mousedown', fn);
        return () => document.removeEventListener('mousedown', fn);
    }, []);

    return (
        <div ref={ref} className="card-anim" style={{ position: 'fixed', left: x, top: y, zIndex: 1000, background: colors.bgContextMenu, borderRadius: 14, boxShadow: colors.shadow, minWidth: 190, border: `1px solid ${colors.border}`, overflow: 'hidden' }}>
            <div style={{ display: 'flex', gap: 4, padding: '8px 10px', borderBottom: `1px solid ${colors.border}` }}>
                {REACTIONS.map(e => (
                    <span key={e} style={{ fontSize: 22, cursor: 'pointer', transition: 'transform .12s cubic-bezier(.22,.68,0,1.4)' }}
                        onClick={() => { onReact(e); onClose(); }}
                        onMouseEnter={ev => ev.target.style.transform = 'scale(1.35)'}
                        onMouseLeave={ev => ev.target.style.transform = 'scale(1)'}
                    >{e}</span>
                ))}
            </div>
            <CMenuItem icon={<IconReply size={15} color={colors.textContextItem}/>} label="Ответить"    colors={colors} onClick={() => { onReply();   onClose(); }} />
            <CMenuItem icon={<IconForward size={15} color={colors.textContextItem}/>} label="Переслать"   colors={colors} onClick={() => { onForward(); onClose(); }} />
            <CMenuItem icon={<IconCopy size={15} color={colors.textContextItem}/>} label="Копировать"  colors={colors} onClick={() => { onCopy();    onClose(); }} />
            <CMenuItem icon={<IconStar size={15} color={colors.textContextItem}/>} label="В избранное" colors={colors} onClick={() => { onSave();    onClose(); }} />
            {isMe && <CMenuItem icon={<IconTrash size={15} color={colors.textContextRed}/>} label="Удалить" colors={colors} onClick={() => { onDelete(); onClose(); }} red />}
        </div>
    );
}

function CMenuItem({ icon, label, onClick, red, colors }) {
    const [hov, setHov] = useState(false);
    return (
        <div onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
            style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 14px', cursor: 'pointer', fontSize: 14, color: red ? colors.textContextRed : colors.textContextItem, background: hov ? colors.bgContextItem : 'transparent' }}>
            {icon}<span style={{marginLeft:2}}>{label}</span>
        </div>
    );
}

function ForwardModal({ onClose, onForward, allChats, myId }) {
    const { colors } = useTheme();
    const [q, setQ] = useState('');
    const filtered = allChats.filter(c => getChatDisplayName(c, myId).toLowerCase().includes(q.toLowerCase()));
    return (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.55)', zIndex: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}
            onClick={e => e.target === e.currentTarget && onClose()}>
            <div className="card-anim" style={{ background: colors.bgModal, borderRadius: 16, padding: 20, width: 340, maxHeight: '80vh', display: 'flex', flexDirection: 'column', border: `1px solid ${colors.border}` }}>
                <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12, color: colors.textPrimary }}>Переслать в...</div>
                <input className="input-focus" style={{ padding: '8px 12px', borderRadius: 10, border: `1.5px solid ${colors.border}`, fontSize: 14, marginBottom: 10, background: colors.bgInput, color: colors.textPrimary, outline: 'none' }} placeholder="Поиск чата..." value={q} onChange={e => setQ(e.target.value)} />
                <div style={{ flex: 1, overflowY: 'auto' }}>
                    {filtered.map(c => (
                        <div key={c._id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 4px', cursor: 'pointer', borderRadius: 8 }}
                            onClick={() => { onForward(c._id); onClose(); }}
                            onMouseEnter={ev => ev.currentTarget.style.background = colors.bgHover}
                            onMouseLeave={ev => ev.currentTarget.style.background = 'transparent'}>
                            <div style={{ width: 36, height: 36, borderRadius: '50%', background: colors.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 14 }}>
                                {getChatDisplayName(c, myId)[0]?.toUpperCase()}
                            </div>
                            <span style={{ fontSize: 14, color: colors.textPrimary }}>{getChatDisplayName(c, myId)}</span>
                        </div>
                    ))}
                </div>
                <button style={{ marginTop: 12, padding: 9, background: colors.bgPill, border: `1px solid ${colors.border}`, borderRadius: 10, cursor: 'pointer', color: colors.textSecondary }} onClick={onClose}>Отмена</button>
            </div>
        </div>
    );
}

export default function ChatWindow({ chat, socket, online, incomingMsg, incomingReaction, clearedChatId, allChats, onNewChat, onBack, onRemoveChat }) {
    const { user, token } = useAuth();
    const { colors } = useTheme();
    const [messages,   setMessages]   = useState([]);
    const [text,       setText]       = useState('');
    const [files,      setFiles]      = useState([]);
    const [typing,     setTyping]     = useState(null);
    const [loading,    setLoading]    = useState(false);
    const [dateGroups, setDateGroups] = useState([]);
    const [replyTo,    setReplyTo]    = useState(null);
    const [ctxMenu,    setCtxMenu]    = useState(null);
    const [fwdMsg,     setFwdMsg]     = useState(null);
    const [sendAnim,   setSendAnim]   = useState(false);
    const bottomRef   = useRef(null);
    const typingTimer = useRef(null);
    const fileRef     = useRef(null);
    const myId = String(user?.id || user?._id || '');

    function upsert(arr, msg) {
        const i = arr.findIndex(m => m._id === msg._id);
        if (i >= 0) { const n = [...arr]; n[i] = msg; return n; }
        return [...arr, msg];
    }
    function rebuild(msgs) { setDateGroups(groupByDate(msgs)); }

    useEffect(() => {
        if (!chat) return;
        setLoading(true);
        apiFetch(`/api/chats/${chat._id}/messages`, {}, token)
            .then(data => { setMessages(data); rebuild(data); })
            .catch(() => {})
            .finally(() => setLoading(false));
        return () => { setMessages([]); setDateGroups([]); };
    }, [chat?._id]);

    useEffect(() => {
        if (!incomingMsg || incomingMsg.chatId !== chat?._id) return;
        setMessages(prev => { const u = upsert(prev, incomingMsg.message); rebuild(u); return u; });
        setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    }, [incomingMsg]);

    useEffect(() => {
        if (!incomingReaction || incomingReaction.chatId !== chat?._id) return;
        setMessages(prev => {
            const u = prev.map(m => m._id === incomingReaction.messageId ? { ...m, reactions: incomingReaction.reactions } : m);
            rebuild(u); return u;
        });
    }, [incomingReaction]);

    useEffect(() => {
        if (!clearedChatId || clearedChatId.chatId !== chat?._id) return;
        setMessages([]); setDateGroups([]);
    }, [clearedChatId]);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [dateGroups]);

    useEffect(() => {
        if (!socket || !chat) return;
        const onDel      = ({ messageId }) => setMessages(prev => { const u = prev.filter(m => m._id !== messageId); rebuild(u); return u; });
        const onTypStart = ({ userId, displayName }) => { if (String(userId) !== myId) setTyping(displayName); };
        const onTypStop  = ({ userId }) => { if (String(userId) !== myId) setTyping(null); };
        socket.on('message:deleted', onDel);
        socket.on('typing:start',    onTypStart);
        socket.on('typing:stop',     onTypStop);
        return () => {
            socket.off('message:deleted', onDel);
            socket.off('typing:start',    onTypStart);
            socket.off('typing:stop',     onTypStop);
        };
    }, [socket, chat?._id, myId]);

    function handleInput(val) {
        setText(val);
        if (!socket || !chat) return;
        socket.emit('typing:start', { chatId: chat._id });
        clearTimeout(typingTimer.current);
        typingTimer.current = setTimeout(() => socket.emit('typing:stop', { chatId: chat._id }), 1500);
    }

    async function handleSend(e) {
        e?.preventDefault();
        if (!text.trim() && !files.length) return;
        const fd = new FormData();
        if (text.trim()) fd.append('text', text.trim());
        if (replyTo)     fd.append('reply_to', replyTo._id);
        files.forEach(f => fd.append('files', f));
        setText(''); setFiles([]); setReplyTo(null);
        socket?.emit('typing:stop', { chatId: chat._id });
        // Send button animation
        setSendAnim(true);
        setTimeout(() => setSendAnim(false), 300);
        try {
            const msg = await apiFetch(`/api/chats/${chat._id}/messages`, { method: 'POST', body: fd }, token);
            setMessages(prev => { const u = upsert(prev, msg); rebuild(u); return u; });
        } catch (e) { alert('Ошибка: ' + e.message); }
    }

    async function handleDelete(msgId) {
        if (!confirm('Удалить сообщение?')) return;
        try { await apiFetch(`/api/messages/${msgId}`, { method: 'DELETE' }, token); }
        catch (e) { alert(e.message); }
    }

    async function handleReact(msgId, emoji) {
        try {
            const updated = await apiFetch(`/api/messages/${msgId}/react`, { method: 'POST', body: JSON.stringify({ emoji }) }, token);
            setMessages(prev => { const u = prev.map(m => m._id === msgId ? { ...m, reactions: updated.reactions } : m); rebuild(u); return u; });
        } catch {}
    }

    async function handleForward(msgId, chatId) {
        try { await apiFetch(`/api/messages/${msgId}/forward`, { method: 'POST', body: JSON.stringify({ chat_id: chatId }) }, token); }
        catch (e) { alert(e.message); }
    }

    async function handleSave(msgId) {
        try { await apiFetch(`/api/messages/${msgId}/save`, { method: 'POST' }, token); }
        catch (e) { alert(e.message); }
    }

    function handleCtx(e, msg) {
        e.preventDefault();
        const x = Math.min(e.clientX, window.innerWidth - 210);
        const y = Math.min(e.clientY, window.innerHeight - 310);
        setCtxMenu({ x, y, msg });
    }

    if (!chat) return (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: colors.bgEmpty }}>
            <IconChat size={68} color={colors.accentLight} />
            <div style={{ fontSize: 18, color: colors.textMuted, fontWeight: 500 }}>Выберите чат</div>
            <div style={{ fontSize: 13, color: colors.textMuted, marginTop: 6, opacity: 0.7 }}>Выберите диалог из списка слева</div>
        </div>
    );

    const isGroup  = chat.type === 'group';
    const isSaved  = chat.type === 'saved';
    const chatName = getChatDisplayName(chat, myId);
    const other    = !isGroup && !isSaved ? chat.members?.find(m => String(m._id || m) !== myId) : null;
    const isOnline = other && online?.has(String(other._id || other));

    function HeaderAvatar() {
        const avatarFile = isGroup ? chat.avatar : other?.avatar;
        const bg     = isSaved ? colors.savedBg : isGroup ? colors.groupBg : (other?.avatar_color || colors.accent);
        const radius = isGroup ? 10 : '50%';
        const letter = isSaved ? '⭐' : chatName[0]?.toUpperCase();
        if (avatarFile) return <img src={fileUrl(avatarFile)} alt="" style={{ width: 40, height: 40, borderRadius: radius, objectFit: 'cover', flexShrink: 0 }} />;
        return <div style={{ width: 40, height: 40, borderRadius: radius, background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 16, flexShrink: 0 }}>{letter}</div>;
    }

    return (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100vh', minWidth: 0 }} onClick={() => setCtxMenu(null)}>
            {/* Шапка */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 16px', borderBottom: `1px solid ${colors.border}`, background: colors.bgHeader, flexShrink: 0, boxShadow: colors.shadowHeader }}>
                <button style={{ background: 'none', border: 'none', fontSize: 22, cursor: 'pointer', padding: '4px 6px', borderRadius: 8, color: colors.textSecondary, display: window.innerWidth <= 640 ? 'flex' : 'none', alignItems: 'center', justifyContent: 'center' }} className="icon-btn-base" onClick={onBack}><IconBack size={22} color={colors.textSecondary} /></button>
                <HeaderAvatar />
                <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 15, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: colors.textPrimary }}>{chatName}</div>
                    <div style={{ fontSize: 12, color: isOnline ? colors.textOnlineStatus : colors.textMuted }}>
                        {isSaved ? 'Сохранённые сообщения'
                            : isGroup ? `${chat.members?.length || 0} участников`
                            : isOnline ? '● В сети' : '○ Не в сети'}
                    </div>
                </div>
            </div>

            {/* Сообщения */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 2, background: colors.bgChat }}>
                {loading && <div style={{ textAlign: 'center', color: colors.textMuted, padding: 20 }}>Загрузка...</div>}
                {dateGroups.map(g => (
                    <div key={g.date}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '12px 0' }}>
                            <span style={{ background: colors.bgDateLabel, color: colors.textDateLabel, fontSize: 11, padding: '3px 12px', borderRadius: 10, userSelect: 'none' }}>{g.date}</span>
                        </div>
                        {g.msgs.map(msg => (
                            <MessageBubble key={msg._id} msg={msg} isGroup={isGroup} myId={myId}
                                onDelete={handleDelete} onReact={handleReact}
                                onContextMenu={handleCtx} />
                        ))}
                    </div>
                ))}
                {messages.length === 0 && !loading && (
                    <div style={{ textAlign: 'center', color: colors.textMuted, padding: 20 }}>Нет сообщений. Напишите первым!</div>
                )}
                {/* Typing indicator */}
                {typing && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '2px 0', marginTop: 4 }}>
                        <div style={{ display: 'flex', gap: 4, background: colors.bgMsgIn, padding: '10px 14px', borderRadius: 16, borderBottomLeftRadius: 4, boxShadow: '0 1px 4px rgba(0,0,0,.08)' }}>
                            <div className="typing-dot" style={{ width: 7, height: 7, borderRadius: '50%', background: colors.accent }}></div>
                            <div className="typing-dot" style={{ width: 7, height: 7, borderRadius: '50%', background: colors.accent }}></div>
                            <div className="typing-dot" style={{ width: 7, height: 7, borderRadius: '50%', background: colors.accent }}></div>
                        </div>
                        <span style={{ fontSize: 12, color: colors.textMuted }}>{typing} печатает...</span>
                    </div>
                )}
                <div ref={bottomRef} />
            </div>

            {/* Панель ответа */}
            {replyTo && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 14px', background: colors.bgReplyBar, borderTop: `1px solid ${colors.border}`, borderLeft: `3px solid ${colors.accent}`, flexShrink: 0 }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: colors.textAccent }}>↩️ {replyTo.from_user?.display_name}</div>
                        <div style={{ fontSize: 12, color: colors.textSecondary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{replyTo.text || '📎 Файл'}</div>
                    </div>
                    <button style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, color: colors.textMuted, padding: 0 }} onClick={() => setReplyTo(null)}>✕</button>
                </div>
            )}

            {/* Превью файлов */}
            {files.length > 0 && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, padding: '7px 14px', background: colors.bgForm, borderTop: `1px solid ${colors.border}`, flexShrink: 0 }}>
                    {files.map((f, i) => (
                        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 4, background: colors.bgFileChip, borderRadius: 12, padding: '3px 8px', fontSize: 12, color: colors.textPrimary }}>
                            <span>{f.type.startsWith('image/') ? '🖼' : f.type.startsWith('video/') ? '🎬' : '📎'}</span>
                            <span style={{ fontSize: 11, maxWidth: 90, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f.name}</span>
                            <button onClick={() => setFiles(p => p.filter((_, j) => j !== i))} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 11, color: colors.textMuted, padding: 0 }}>✕</button>
                        </div>
                    ))}
                </div>
            )}

            {/* Поле ввода */}
            <form onSubmit={handleSend} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 14px', background: colors.bgForm, borderTop: `1px solid ${colors.border}`, flexShrink: 0 }}>
                <label style={{ background: 'none', border: 'none', fontSize: 22, borderRadius: 8, display: 'flex', alignItems: 'center', cursor: 'pointer', color: colors.textSecondary, padding: '4px' }} className="icon-btn-base">
                    <IconAttach size={20} color={colors.textSecondary} />
                    <input ref={fileRef} type="file" multiple accept="*/*" style={{ display: 'none' }} onChange={e => setFiles(p => [...p, ...Array.from(e.target.files)])} />
                </label>
                <input
                    className="input-focus"
                    style={{ flex: 1, padding: '10px 14px', borderRadius: 22, border: `1.5px solid ${colors.border}`, fontSize: 15, outline: 'none', minWidth: 0, background: colors.bgInput, color: colors.textPrimary }}
                    placeholder="Написать сообщение..." style={{ flex: 1, padding: "10px 14px", borderRadius: 22, border: `1.5px solid ${colors.border}`, fontSize: "var(--app-size, 15px)", outline: "none", minWidth: 0, background: colors.bgInput, color: colors.textPrimary, fontFamily: "var(--app-font)" }}
                    value={text}
                    onChange={e => handleInput(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) handleSend(e); }}
                />
                <button
                    type="submit"
                    className={`send-btn-base${sendAnim ? ' send-btn-anim' : ''}`}
                    style={{ background: colors.sendBtn, color: colors.sendBtnText, border: 'none', borderRadius: '50%', width: 42, height: 42, fontSize: 18, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, opacity: (!text.trim() && !files.length) ? 0.45 : 1, boxShadow: `0 3px 10px rgba(123,31,58,.3)` }}
                    disabled={!text.trim() && !files.length}><IconSend size={17} color="#fff" /></button>
            </form>

            {/* Контекст-меню сообщения */}
            {ctxMenu && (
                <MsgContextMenu
                    x={ctxMenu.x} y={ctxMenu.y} msg={ctxMenu.msg}
                    isMe={String(ctxMenu.msg.from_user?._id || ctxMenu.msg.from_user) === myId}
                    onClose={() => setCtxMenu(null)}
                    onReply={() => setReplyTo(ctxMenu.msg)}
                    onForward={() => setFwdMsg(ctxMenu.msg)}
                    onSave={() => handleSave(ctxMenu.msg._id)}
                    onReact={emoji => handleReact(ctxMenu.msg._id, emoji)}
                    onDelete={() => handleDelete(ctxMenu.msg._id)}
                    onCopy={() => navigator.clipboard?.writeText(ctxMenu.msg.text || '')}
                />
            )}

            {/* Модальное окно пересылки */}
            {fwdMsg && (
                <ForwardModal
                    allChats={allChats} myId={myId}
                    onClose={() => setFwdMsg(null)}
                    onForward={chatId => handleForward(fwdMsg._id, chatId)}
                />
            )}
        </div>
    );
}
